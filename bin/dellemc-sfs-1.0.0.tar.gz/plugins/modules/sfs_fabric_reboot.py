#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs fabric reboot 
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
description:

  - Node reboot for Leaf-Spine Weaver to apply the general fabric property changes on Dell SmartFabric Solutions.

options:
            'node_id': {
            'type': 'str',
            'required': False
            }

'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    dellemc.sfs
    ansible.legacy
  tasks:
    - name: Provision Configs
      block:
        - name: fabric reboot
          dellemc.sfs.sfs_fabric_reboot:
            node_id: "VB90DD3"
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible_collections.ansible.netcommon.plugins.module_utils.network.restconf import (
        restconf,
)

from ansible.module_utils.basic import AnsibleModule


class SFSFabricReboot(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'node_id': {
                'type': 'str',
                'required': False
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'NodeId' : 'node_id'
                }

        self.path = "Nodes('%s')/Nodes.Reboot"    % (self.module.params['node_id'])
        self.resource_id = self.module.params['node_id']

if __name__ == "__main__":
    SFSFabricReboot().execute_module()
