#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_backup
author: "Kalaivani Baskaran" <kalaivanibaskaran.ba@Dellteam.com>
short_description: Backup and restore functionality on Dell SmartFabric services.
description:
  - module takes backup and redirect it to the given file locally. 

'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    dellemc.sfs
  tasks:
    - name: Get Backup
      block:
        - name: SFS Backup
          dellemc.sfs.sfs_backup:
            file_name: 'backup.json'
          register: result
    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule
import json

class SFSBackup(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'file_name': {
                'type': 'str',
                'required': True
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module, False)
        self.payload_arg_map = { }
        
        self.path = "Backup"

if __name__ == "__main__":
    sfs_backup = SFSBackup()
    result = sfs_backup.get_module_config()
    f = open(sfs_backup.module.params['file_name'], 'w')
    f.write(json.dumps(result['response']))
    sfs_backup.module.exit_json(**result)
