#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure preferred_master
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure preferred master on Dell SmartFabric services.
description:
  - module provides configuration management of preferred master.

options:
    'node_id': {
        'type': 'str',
        'required': False
    },
    'preferred_master': {
        'type': 'bool',
        'required': False
    }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:

        - name: Set/Reset Preferred Master
          dellemc.sfs.sfs_preferred_master:
            node_id: VB98B3B
            preferred_master: 'False'
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result
'''

from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule



class SFSPreferredMaster(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'node_id': {
                'type': 'str',
                'required': False
            },
            'preferred_master': {
                'type': 'bool',
                'required': False
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'NodeId' : 'node_id',
                'PreferredMaster' : 'preferred_master'
                }

        self.path = "FabricNodes"
        self.resource_id = self.module.params['node_id']

if __name__ == "__main__":
    SFSPreferredMaster().execute_module()
