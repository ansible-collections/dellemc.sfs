#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_system_route_maps_rules
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure route maps rules on Dell SmartFabric Solutions.
description:
  - module provides configuration management of route maps rules. 

options:
            'seq_no': {
                'type': 'int',
                'required': False
            },
            'match_ipv4_route_prefixList': {
                'type': 'str',
                'required': False
            },
            'match_ipv4_aclList': {
                'type': 'str',
                'required': False
            },
            'packet_handling': {
                'type': 'str',
                'required': False
            },
            'action_ipv4_next_hoplist': {
                'type': 'list',
                'required': False
            },
            'ipV4_address': {
                'type': 'str',
                'required': False
            },
            'vrf': {
                'type': 'str',
                'required': False
            },
            'map_id': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Route Maps Rules
          dellemc.sfs.sfs_route_maps_rules:
            map_id: "route-map-1"
            seq_no: 10
            match_ipv4_route_prefixList: "v4-prefix-1"
            match_ipv4_aclList: "acl-match-1"
            packet_handling: "Permit"
            action_ipv4_next_hoplist: [{ IpV4Address: "2.2.2.2",Vrf: "default"}]
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result

'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule

class SFSRouteMapsRules(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'seq_no': {
                'type': 'int',
                'required': False
            },
            'match_ipv4_route_prefixList': {
                'type': 'str',
                'required': False
            },
            'match_ipv4_aclList': {
                'type': 'str',
                'required': False
            },
            'packet_handling': {
                'type': 'str',
                'required': False
            },
            'action_ipv4_next_hoplist': {
                'type': 'list',
                'required': False
            },
            'ipV4_address': {
                'type': 'str',
                'required': False
            },
            'vrf': {
                'type': 'str',
                'required': False
            },
            'map_id': {
                'type': 'str',
                'required': False
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'SeqNo' : 'seq_no',
                'MatchIpV4RoutePrefixList' : 'match_ipv4_route_prefixList',
                'MatchIpV4AclList' : 'match_ipv4_aclList',
                'PacketHandling' : 'packet_handling',
                'ActionIpV4NextHopList' : 'action_ipv4_next_hoplist'
                #'IpV4Address' : 'ipV4_address',
                #'Vrf' : 'vrf'
                }

        self.path = "RouteMaps('%s')/Rules"       % (self.module.params['map_id'])
        self.resource_id = self.module.params['seq_no']

if __name__ == "__main__":
    SFSRouteMapsRules().execute_module()


