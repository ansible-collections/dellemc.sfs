#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_system_uplink
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure uplinks on Dell SmartFabric services.
description:
  - module provides configuration management of uplinks.

options:
                'node': {
                'type': 'str',
                'required': True
                },
                'uplink_name': {
                'type': 'str',
                'required': True
                },
                'uplink_description': {
                'type': 'str',
                'required': False
                },
                'uplink_id': {
                'type': 'str',
                'required': True
                },
                'media_type': {
                'type': 'str',
                'required': False,
                'default': 'Ethernet'
                },
                'configuration_interfaces': {
                'type': 'list',
                'required': False
                },
                'tagged_networks': {
                'type': 'list',
                'required': False
                },
                'untagged_network': {
                'type': 'str',
                'required': False
                },
                'lag_type': {
                'type': 'str',
                'required': False,
                'default': 'Dynamic',
                'choices': [ 'Static', 'Dynamic' ]
                },
                'uplink_type': {
                'type': 'str',
                'required': False,
                'default': 'Normal',
                'choices': [ 'Normal', 'JumpBox' ]
                },
                'native_vlan': {
                'type': 'int',
                'required': False
                },
                'ingress_ipacl': {
                'type': 'str',
                'required': False
                }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
     - name: Provision Configs
       block:
          - name: Update uplink
            dellemc.sfs.sfs_uplink:
               uplink_id: 1
               node: 97JBJ23
               uplink_name: New Uplink
               uplink_description: New Uplink description 2
               configuration_interfaces:
                  - 97JBJ23:ethernet1/1/41
                  - 97K5J23:ethernet1/1/41
               tagged_networks:
                  - VLAN1200
               untagged_network: VLAN 1
               native_vlan: 100
               ingress_ipacl: "UplinkIngressIpACL"
               state: "present"
            register: result

     - name: Debug the result
       debug: var=result
'''

from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule

class SFSUplink(SFSConfig):
    def __init__(self):
        argument_spec = {
                'state': {
                'type': 'str',
                'default': "present",
                'required': False
                },
                'node': {
                'type': 'str',
                'required': True
                },
                'uplink_name': {
                'type': 'str',
                'required': True
                },
                'uplink_description': {
                'type': 'str',
                'required': False
                },
                'uplink_id': {
                'type': 'str',
                'required': True
                },
                'media_type': {
                'type': 'str',
                'required': False,
                'default': 'Ethernet'
                },
                'configuration_interfaces': {
                'type': 'list',
                'required': False
                },
                'tagged_networks': {
                'type': 'list',
                'required': False
                },
                'untagged_network': {
                'type': 'str',
                'required': False
                },
                'lag_type': {
                'type': 'str',
                'required': False,
                'default': 'Dynamic',
                'choices': [ 'Static', 'Dynamic' ]
                },
                'uplink_type': {
                'type': 'str',
                'required': False,
                'default': 'Normal',
                'choices': [ 'Normal', 'JumpBox' ]
                },
                'native_vlan': {
                'type': 'int',
                'required': False
                },
                'ingress_ipacl': {
                'type': 'str',
                'required': False
                }

            }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'UplinkId' : 'uplink_id', 
                'Name' : 'uplink_name', 
                'Description' : 'uplink_description',
                'MediaType' : 'media_type',
                'LagType' : 'lag_type', 
                'UplinkType' : 'uplink_type',
                'NativeVlan' : 'native_vlan',
                'IngressIpAcl' : 'ingress_ipacl'
                }
        # Find fabric id and update path
        self.update_path()

    def update_path(self):
        node = self.module.params['node']
        node_result = self.get_path_config("Nodes('%s')" % (node))
        fabric_id =  node_result['FabricId']
        if not fabric_id:
            self.module.fail_json(msg="Could not get Fabric id for node %s" %(node))
        self.path = "Fabrics('%s')/Uplinks" % (fabric_id)
        self.resource_id = self.module.params['uplink_id']

    def running_to_payload(self, data):
        if not data:
            return None
        if 'ConfiguredInterfaces' in data:
            new_value = [ {'InterfaceName' : extract_id_value(intf)} for intf in data['ConfiguredInterfaces']]
            data['ConfiguredInterfaces'] = new_value
        if 'Networks' in data:
            new_value = [ {'NetworkId' : extract_id_value(network) for network in data['Networks']}]
            data['Networks'] = new_value
        if 'UntaggedNetwork' in data:
            new_value = {'NetworkId' : extract_id_value(data['UntaggedNetwork'])}
            data['UntaggedNetwork'] = new_value
        return data

    def candidate_to_payload(self, data):
        payload = super(SFSUplink, self).candidate_to_payload(data)
        if 'configuration_interfaces' in data:
            if data['configuration_interfaces'] != None:
                payload['ConfiguredInterfaces'] = [{'InterfaceName' : intf} for intf in data['configuration_interfaces']]
        if 'tagged_networks' in data:
            if data['tagged_networks'] != None:
                payload['Networks'] = [{'NetworkId' : network} for network in data['tagged_networks']]
        if 'untagged_network' in data:
            if data['untagged_network'] != None:
                payload['UntaggedNetwork'] = {'NetworkId' : data['untagged_network']}
        return payload

if __name__ == "__main__":
    SFSUplink().execute_module()
