#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_sfs_setup
author: "Kalaivani Baskaran <kalaivani_baskaran_b@Dellteam.com>
short_description: Configure L3 Fabric on Dell SmartFabric services.
description:
    -  module provides configuration management of L3 fabric
options:
            
            'service_enable': {
                'type': 'bool',
                'required': True
            },
            'icl_ports': {
                'type': 'list',
                'required': False
            },
            'role': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
         - name: Create L3 Fabric node as Spine
           dellemc.sfs.sfs_setup:
             service_enable: true
             role: SPINE
             state: 'present'
           register: result

         - name: Create L3 Fabric without VLTi(Isilon)
           dellemc.sfs.sfs_setup:
             service_enable: true
             role: LEAF
             state: 'present'
           register: result

         - name:reate L3 Fabric with VLTi(VxRail)
           dellemc.sfs.sfs_setup:
             service_enable: true
             icl_ports:
               - ethernet1/1/5
               - ethernet1/1/6
             role: LEAF
             register: result
             state: 'present'
           register: result

         - name: Disable L3 Fabric
           dellemc.sfs.sfs_setup:
             service_enable: false
             state: 'present'
           register: result

    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible_collections.ansible.netcommon.plugins.module_utils.network.restconf import (
        restconf,
)

from ansible.module_utils.basic import AnsibleModule

class SFSSetUp(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'service_enable': {
                'type': 'bool',
                'required': True
            },
            'icl_ports': {
                'type': 'list',
                'required': False
            },
            'domain_id': {
                'type': 'str',
                'required': False
            },
            'role': {
                'type': 'str',
                'required': False
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module, False)
        self.payload_arg_map = {
                'service-enable' : 'service_enable',
                'icl' : 'icl_ports',
                'domain-id' : 'domain_id',
                'role' : 'role'
                }

        self.path = "dell-smart-fabric:config-personality"
        self.redfish_support = False
        self.content_type = 'application/json'
        # Get running config is set to false as config(config-personality) and 
        # GET(show-personality) has 2 different models. Comparing candidate and running
        # config is not necessary as few fields differ between config and get models
        self.is_get_running = False

if __name__ == "__main__":
    SFSSetUp().execute_module()
