#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_network
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure VLANs protocol,VXLAN, L3_ROUTED, L3, settings on a Dell SmartFabric services..
description:

  - module provides configuration management of a Network.

options:
    
            'network_id': {
                'type': 'str',
                'required': True
            },
            'network_name': {
                'type': 'str',
                'required': False
            },
            'network_description': {
                'type': 'str',
                'required': False
            },
            'qos_priority': {
                'type': 'str',
                'default': "Iron",
                'required': False,
                'choices': ['Platinum', 'Gold', 'System', 'Iron', 'Silver', 'Bronze']
            },
            'vlan_min': {
                'type': 'int',
                'required': False
            },
            'vlan_max': {
                'type': 'int',
                'required': False
            },
            'network_type': {
                'type': 'str',
                'required': True,
                'choices': ['VXLAN', 'L3_ROUTED', 'L3', 'GeneralPurpose' ]
            },
            'address_family': {
                'type': 'str',
                'required': False,
                'choices': ['inet']
            },
            'prefix_length': {
                'type': 'int',
                'required': False
            },
            'ip_address_list': {
                'type': 'list',
                'required': False
            },
            'helper_address': {
                'type': 'list',
                'required': False
            },
            'gateway_ip_address': {
                'type': 'list',
                'required': False
            },
            'virtual_network': {
                'type': 'str',
                'required': False
            },
            'route_map': {
                'type': 'str',
                'required': False
            },
            'originator': {
                'type': 'str',
                'required': False
            },
            'rack_settings': {
                'type': 'str',
                'required': False
            },
            'rack_id': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Privision Configs
      block:

        - name: sfs_network
          dellemc.sfs.sfs_network:
             network_name: "sfs_network"
             network_id: "Leaf-test-GeneralPurpose"
             vlan_min: 752
             vlan_max: 752
             qos_priority: "Gold"
             network_type: "GeneralPurpose"
             network_description: "SFS Network Create Test From Ansible-ddddd"
             address_family: "inet"
             virtual_network: "vn752"
             state: "present"
          register: result

        - name: Update Network
          dellemc.sfs.sfs_network:
             network_id: "My_L3_ROUTED_Network_Id_1"
             network_name: "My_L3_ROUTED_Network_Name_1"
             network_description: "My_L3_ROUTED_Network_Description_1"
             network_type: "L3_ROUTED"
             qos_priority: "Bronze"
             address_family: "inet"
             prefix_length: 24
             ip_address_list: ["192.168.1.2","192.168.1.4"]
             helper_address: ["10.10.10.10","11.11.11.11"]
             gateway_ip_address: ["192.168.1.3"]
             route_map: "routemap1"
             state: "present"
          register: result

        - name: Update VXLAN Network
          dellemc.sfs.sfs_network:
             network_id: "My_VXLAN_Network_Id"
             vlan_min: 400
             vlan_max: 400
             qos_priority: "Bronze"
             network_type: "VXLAN"
             virtual_network: "vnet1"
             network_name: "My_VXLAN_Network_Id"
             network_description: "My_VXLAN_Network_Description"
             originator: "vCenter_user"
             state: "present"
          register: result

        - name: MULTIRACK L3 VLAN
          dellemc.sfs.sfs_network:
             network_id: "SREEJITHNETWORK1"
             network_name: "Network1"
             network_description: "My_L3 VLAN_Network_Description_1"
             vlan_max: 401
             vlan_min: 401
             qos_priority: "Iron"
             network_type: "MULTIRACK_L3_VLAN"
             rack_settings: [{ RackID: "6298f46c-b8a8-4548-8bfb-14ee34303147", AddressFamily: "inet", PrefixLen: 24, GateWayIpAddress: ["10.1.1.254"],
             IpAddressList: ["10.1.1.1","10.1.1.2"], HelperAddress: ["10.10.10.10","10.11.11.11"] }]
             state: "present"
          register: result

    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible_collections.ansible.netcommon.plugins.module_utils.network.restconf import (
        restconf,
)

from ansible.module_utils.basic import AnsibleModule

class SFSNetwork(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'network_id': {
                'type': 'str',
                'required': True
            },
            'network_name': {
                'type': 'str',
                'required': False
            },
            'network_description': {
                'type': 'str',
                'required': False
            },
            'qos_priority': {
                'type': 'str',
                'default': "Iron",
                'required': False,
                'choices': ['Platinum', 'Gold', 'System', 'Iron', 'Silver', 'Bronze']
            },
            'vlan_min': {
                'type': 'int',
                'required': False
            },
            'vlan_max': {
                'type': 'int',
                'required': False
            },
            'network_type': {
                'type': 'str',
                'required': True,
                'choices': ['VXLAN', 'L3_ROUTED', 'L3', 'GeneralPurpose', 'MULTIRACK_L3_VLAN' ]
            },
            'address_family': {
                'type': 'str',
                'required': False,
                'choices': ['inet']
            },
            'prefix_length': {
                'type': 'int',
                'required': False
            },
            'ip_address_list': {
                'type': 'list',
                'required': False
            },
            'helper_address': {
                'type': 'list',
                'required': False
            },
            'gateway_ip_address': {
                'type': 'list',
                'required': False
            },
            'virtual_network': {
                'type': 'str',
                'required': False
            },
            'route_map': {
                'type': 'str',
                'required': False
            },
            'originator': {
                'type': 'str',
                'required': False
            },
            'rack_settings': {
                'type': 'str',
                'required': False
            },
            'rack_id': {
                'type': 'str',
                'required': False
            }


        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'NetworkId' : 'network_id',
                'NetworkName' : 'network_name',
                'NetworkType' : 'network_type',
                'Description' : 'network_description',
                'QosPriority' : 'qos_priority',
                'VlanMinimum' : 'vlan_min',
                'VlanMaximum' : 'vlan_max',
                'AddressFamily' : 'address_family',
                'PrefixLen' : 'prefix_length',
                'IpAddressList' : 'ip_address_list',
                'HelperAddress' : 'helper_address',
                'GateWayIpAddress' : 'gateway_ip_address',
                'VirtualNetwork' : 'virtual_network',
                'RouteMap' : 'route_map'
                'RackSettings' : 'rack_settings',  
                'Originator' : 'originator',
                'RackID' : 'rack_id'

                }

        self.path = "Networks"
        self.resource_id = self.module.params['network_id']

if __name__ == "__main__":
    SFSNetwork().execute_module()
