#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_system_route_policy
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure route policie on Dell SmartFabric services.
description:
  - module provides configuration management of route policies.The route policy must be associated with a node through the sfs-node-policy-mapping.

options:
            'policy_id': {
                'type': 'str',
                'required': True
            },
            'policy_name': {
                'type': 'str',
                'required': True
            },
            'policy_description': {
                'type': 'str',
                'required': False
            },
            'policy_type': {
                'type': 'str',
                'required': True,
                #'choices': [1,2]
            },
            'address_family_type': {
                'type': 'str',
                'required': False,
                'choices': ['ipv4']
            },
            'remote_address': {
                'type': 'str',
                'required': False
            },
            'remote_loopback_address': {
                'type': 'str',
                'required': False
            },
            'remote_as': {
                'type': 'int',
                'required': False
            },
            'sender_side_loop_detection': {
                'type': 'bool',
                'required': False
            },
            'route_filter_enable': {
                'type': 'bool',
                'required': False
            },
            'ipv4_nexthop_ip': {
                'type': 'str',
                'required': False
            },
            'ipv4_address_prefix': {
                'type': 'str',
                'required': False
            },
            'ipv4_prefix_len': {
                'type': 'int',
                'required': False
            },
            'ebgpMulti_hop_count': {
                'type': 'int',
                'required': True
            },
            'bfd_neighbor_enable': {
                'type': 'int',
                'required': True
            }

'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
     - name: Provision Configs
       block:
          - name: Route Policy
            dellemc.sfs.sfs_route_policy:
               policy_id: "policybgp100"
               policy_name: "policybgp100"
               policy_description: "description"
               address_family_type: "ipv4"
               remote_address: "100.100.100.22"
               remote_loopback_address: "100.100.100.2"
               remote_as: 65004
               policy_type: RoutePolicyEbgp
               sender_side_loop_detection: 1
               route_filter_enable: 0
               ebgpMulti_hop_count: 2
               bfd_neighbor_enable: 1
               state: present 
             register: result

     - name: Debug the result
       debug: var=result

'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule

class SFSRoutePolicy(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'policy_id': {
                'type': 'str',
                'required': True
            },
            'ebgpMulti_hop_count': {
                'type': 'int',
                'required': True
            },
            'bfd_neighbor_enable': {
                'type': 'int',
                'required': True
            },
            'policy_name': {
                'type': 'str',
                'required': True
            },
            'policy_description': {
                'type': 'str',
                'required': False
            },
            'policy_type': {
                'type': 'str',
                'required': True,
                #'choices': [1,2]
            },
            'address_family_type': {
                'type': 'str',
                'required': False,
                'choices': ['ipv4']
            },
            'remote_address': {
                'type': 'str',
                'required': False
            },
            'remote_loopback_address': {
                'type': 'str',
                'required': False
            },
            'remote_as': {
                'type': 'int',
                'required': False
            },
            'sender_side_loop_detection': {
                'type': 'bool',
                'required': False
            },
            'route_filter_enable': {
                'type': 'bool',
                'required': False
            },
            'ipv4_nexthop_ip': {
                'type': 'str',
                'required': False
            },
            'ipv4_address_prefix': {
                'type': 'str',
                'required': False
            },
            'ipv4_prefix_len': {
                'type': 'int',
                'required': False
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'PolicyId': 'policy_id',
                'PolicyType': 'policy_type',
                'Name': 'policy_name',
                'Description': 'policy_description',
                'RemoteAS': 'remote_as',
                'RemoteAddress': 'remote_address',
                'RemoteLoopbackAddress': 'remote_loopback_address',
                'AddressFamilyType': 'address_family_type',
                'SenderSideLoopDetection': 'sender_side_loop_detection',
                'RouteFilterEnable': 'route_filter_enable',
                'Ipv4AddressPrefix': 'ipv4_address_prefix',
                'Ipv4PrefixLen': 'ipv4_prefix_len',
                'EbgpMultiHopCount': 'ebgpMulti_hop_count',
                'BfdNeighborEnable': 'bfd_neighbor_enable',
                'Ipv4NextHopIp': 'ipv4_nexthop_ip',
                }
        self.path = "RoutePolicies"
        self.resource_id = self.module.params['policy_id']

if __name__ == "__main__":
    SFSRoutePolicy().execute_module()


