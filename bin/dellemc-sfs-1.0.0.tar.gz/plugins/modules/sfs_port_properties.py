#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_port_properties
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Port properties configuration.
description:
  -  Setting up the port properties such as mtu, auto-neg, configured-speed, admin-status, name and description.

options:
            'interface_name': {
                'type': 'str',
                'required': False
            },
            'description': {
                'type': 'str',
                'required': False
            },
            'admin_status': {
                'type': 'str',
                'required': False
            },
            'mtu': {
                'type': 'int',
                'required': False
            },
            'auto_neg': {
                'type': 'str',
                'required': False
            },
            'configured_speed': {
                'type': 'int',
                'required': False
            },
            'auto_neg': {
                'type': 'str',
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'target_port': {
                'type': 'str',
                'required': False
            },
            'node_id': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Port property configuration
          dellemc.sfs.sfs_port_properties:
             name: ethernet1/1/8
             target_port: OS10SIM:ethernet1/1/8
             description: Interface_8
             node_id: OS10SIM
             admin_status: Enabled
             mtu: 9216
             auto_neg: Enabled
             configured_speed: 0
             state: 'present'
           register: result

     - name: Debug the result
       debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule


class SFSPortProperties(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'description': {
                'type': 'str',
                'required': False
            },
            'admin_status': {
                'type': 'str',
                'required': False
            },
            'mtu': {
                'type': 'int',
                'required': False
            },
            'auto_neg': {
                'type': 'str',
                'required': False
            },
            'configured_speed': {
                'type': 'int',
                'required': False
            },
            'auto_neg': {
                'type': 'str',
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'target_port': {
                'type': 'str',
                'required': False
            },
            'node_id': {
                'type': 'str',
                'required': False
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'Description' : 'description',
                'NodeId' : 'node_id',
                'AdminStatus' : 'admin_status',
                'Mtu' : 'mtu',
                'AutoNeg' : 'auto_neg',
                'ConfiguredSpeed' : 'configured_speed',
                'Name' : 'name',
                'AutoNeg' : 'auto_neg'
                }

        self.path = "Interfaces('%s')"    % (self.module.params['target_port'])
        self.resource_id = self.module.params['description']

if __name__ == "__main__":
    SFSPortProperties().execute_module()
