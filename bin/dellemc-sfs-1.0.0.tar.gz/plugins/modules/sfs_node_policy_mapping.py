#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_node_policy_mapping
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure SFS node-policy-mapping on Dell SmartFabric services.
description:
  - module provides configuration management of SFS node-policy-mapping.It supports CREATE,  DELETE operations. Route policy must be created using the sfs-route-policy before the policy mapping is invoked.

options:
     'node': {
     'type': 'str',
     'required': True
     },
     'policy_list': {
     'type': 'list',
     'required': True
     }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Node Policy Mapping
          dellemc.sfs.sfs_node_policy_mapping:
             node: 19HQXC2
             policy_list:
                - policybgp100
                - policybgp101
             state: "present"  
           register: result

    - name: Debug the result
      debug: var=result
'''

from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule

class SFSNodePolicyMapping(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'node': {
                'type': 'str',
                'required': True
            },
            'policy_list': {
                'type': 'list',
                'required': True
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'NodeId' : 'node',
                'PolicyId' : 'policy_list'
                }
        self.path = "FabricNodes"
        self.resource_id = self.module.params['node']

if __name__ == "__main__":
    SFSNodePolicyMapping().execute_module()
