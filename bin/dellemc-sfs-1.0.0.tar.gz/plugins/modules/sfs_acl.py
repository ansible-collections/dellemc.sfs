#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_acl
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure acl's on Dell SmartFabric Solutions.
description:
  - module provides configuration management of acl's.

options:
            'name': {
                'type': 'str',
                'required': False
            },
            'description_string': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: ACL configurations
          dellemc.sfs.sfs_acl:
            name: "uplink-acl"
            description_string: "uplinkAclDescription"
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule


class SFSAcl(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'description_string': {
                'type': 'str',
                'required': False
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'Name' : 'name',
                'DescriptionString' : 'description_string'
                }

        self.path = "IpAcls"
        self.resource_id = self.module.params['name']

if __name__ == "__main__":
    SFSAcl().execute_module()
