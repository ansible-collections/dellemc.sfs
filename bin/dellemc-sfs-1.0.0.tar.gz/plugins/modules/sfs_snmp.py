#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure sfs_snmp
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure SNMP Server Host on Dell SmartFabric Solutions.
description:
  - module provides configuration management of SNMP Server Host. 

options:
            'host_ipaddress': {
                'type': 'str',
                'required': False
            },
            'address_family': {
                'type': 'str',
                'required': False
            },
            'snmp_version': {
                'type': 'str',
                'default': "v1",
                'required': False,
                'choices': ['v1', 'v2c', 'v3']
            },
            'community': {
                'type': 'str',
                'required': False
            },
            'snmp_securitylevel': {
                'type': 'str',
                'default': "noauth",
                'required': False,
                'choices': ['noauth', 'auth', 'priv']
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: SNMP Server
          dellemc.sfs.sfs_snmp:
            host_ipaddress: "192.168.5.3"
            address_family: "inet"
            snmp_version: "v3"
            community: "v3community"
            snmp_securitylevel: "noauth"
            state: "present"
          register: result

    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule


class SFSSNMP(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'host_ipaddress': {
                'type': 'str',
                'required': False
            },
            'address_family': {
                'type': 'str',
                'required': False
            },
            'snmp_version': {
                'type': 'str',
                'default': "v1",
                'required': False,
                'choices': ['v1', 'v2c', 'v3']
            },
            'community': {
                'type': 'str',
                'required': False
            },
            'snmp_securitylevel': {
                'type': 'str',
                'default': "noauth",
                'required': False,
                'choices': ['noauth', 'auth', 'priv']
            }
        }

        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'HostIpAddress' : 'host_ipaddress',
                'AddressFamily' : 'address_family',
                'SNMPVersion' : 'snmp_version',
                'Community' : 'community',
                'SNMPSecurityLevel' : 'snmp_securitylevel'
                }

        self.path = "NetworkFabricGlobalConfig/SnmpHosts"
        self.resource_id = self.module.params['host_ipaddress']

if __name__ == "__main__":
    SFSSNMP().execute_module()
