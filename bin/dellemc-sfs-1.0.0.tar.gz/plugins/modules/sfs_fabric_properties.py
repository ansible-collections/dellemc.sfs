#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_system_fabric_properties
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure Fabric Properties on Dell SmartFabric Solutions.
description:
  - module provides configuration management of Fabric properties. 

options:
            'leaf_asn': {
                'type': 'int',
                'required': False
            },
            'spine_asn': {
                'type': 'int',
                'required': False
            },
            'private_subnet_prefix': {
                'type': 'str',
                'required': False
            },
            'private_prefix_len': {
                'type': 'int',
                'required': False
            },
            'global_subnet_prefix': {
                'type': 'str',
                'required': False
            },
            'global_prefix_len': {
                'type': 'int',
                'required': False
            },
            'client_control_vlan': {
                'type': 'int',
                'required': False
            },
            'client_management_vlan': {
                'type': 'int',
                'required': False
            },
            'designated_leader_nodes': {
                'type': 'list',
                'required': False
            },
            'designated_leader_backOff_timer': {
                'type': 'int',
                'required': False
            },
            'description': {
                'type': 'str',
                'required': False
            },
            'domain_id': {
                'type': 'int',
                'required': False
            },
            'mdns_publish': {
                'type': 'str',
                'required': False
            },
            'Stp_mode': {
                'type': 'str',
                'default': "mst",
                'required': False,
                'choices': ['mst', 'rapid-pvst']
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Fabric properties
          dellemc.sfs.sfs_fabric_properties:
            leaf_asn: 65013
            spine_asn: 65012
            private_subnet_prefix: "172.16.0.0"
            private_prefix_len: 16
            global_subnet_prefix: "172.30.0.0"
            global_prefix_len: 16
            client_control_vlan: 3939
            client_management_vlan: 4091
            domain_id: 100
            mdns_publish: "disable"
            designated_leader_nodes: ["6HH5XC2", "7KH5XC2"]
            designated_leader_backOff_timer: 3
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result

'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule


class SFSFabricProperties(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'leaf_asn': {
                'type': 'int',
                'required': False
            },
            'spine_asn': {
                'type': 'int',
                'required': False
            },
            'private_subnet_prefix': {
                'type': 'str',
                'required': False
            },
            'private_prefix_len': {
                'type': 'int',
                'required': False
            },
            'global_subnet_prefix': {
                'type': 'str',
                'required': False
            },
            'global_prefix_len': {
                'type': 'int',
                'required': False
            },
            'client_control_vlan': {
                'type': 'int',
                'required': False
            },
            'client_management_vlan': {
                'type': 'int',
                'required': False
            },
            'designated_leader_nodes': {
                'type': 'list',
                'required': False
            },
            'designated_leader_backOff_timer': {
                'type': 'int',
                'required': False
            },
            'description': {
                'type': 'str',
                'required': False
            },
            'domain_id': {
                'type': 'int',
                'required': False
            },
            'mdns_publish': {
                'type': 'str',
                'required': False
            },
            'Stp_mode': {
                'type': 'str',
                'default': "mst",
                'required': False,
                'choices': ['mst', 'rapid-pvst']
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'LeafASN' : 'leaf_asn',
                'SpineASN' : 'spine_asn',
                'PrivateSubnetPrefix' : 'private_subnet_prefix',
                'PrivatePrefixLen' : 'private_prefix_len',
                'Description' : 'description',
                'DomainId' : 'domain_id',
                'MdnsPublish' : 'mdns_publish',
                'GlobalSubnetPrefix' : 'global_subnet_prefix',
                'GlobalPrefixLen' : 'global_prefix_len',
                'ClientControlVlan' : 'client_control_vlan',
                'ClientManagementVlan' : 'client_management_vlan',
                'DesignatedLeaderNodes' : 'designated_leader_nodes',
                'DesignatedLeaderBackOffTimer' : 'designated_leader_backOff_timer',
                'StpMode' : 'Stp_mode'
                }

        self.path = "NetworkFabricGlobalConfig/L3FabricGlobals"
        self.resource_id = self.module.params['leaf_asn']

if __name__ == "__main__":
    SFSFabricProperties().execute_module()
