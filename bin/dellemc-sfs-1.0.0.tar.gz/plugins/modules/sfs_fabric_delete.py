#!/usr/bin/env python
# -*- coding: utf-8 -*-


from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_fabric_delete
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure fabric handler on Dell SmartFabric Solutions.
description:

  - module provides configuration management of fabric handler.

options:

            'node_id': {
                'type': 'str',
                'required': False
            },
            'fabric_design': {
                'type': 'str',
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'design_node': {
                'type': 'str',
                'required': False
            },
            'fabric_design_mappings': {
                'type': 'list',
                'required': False
            },
            'nodes': {
                'type': 'list',
                'required': False
            },
            'fabric_id': {
                'type': 'str',
                'required': False
            },
            'description': {
                'type': 'str',
                'required': False
            },
            'physical_node': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Fabric delete 
          dellemc.sfs.sfs_fabric_delete:
            fabric_design: "2xMX9116n_Fabric_Switching_Engines_in_same_chassis"
            fabric_design_mappings: [{ "DesignNode": "Switch-A","PhysicalNode": "HMXBPK2"},
                 { "DesignNode": "Switch-B","PhysicalNode": "97JBJ23"}]
            name:  "Some New Fabric"
            description: "This is a new Fabric"
            nodes: [{ "NodeId": "HMXBPK2"},{ "NodeId": "97JBJ23"}]
            fabric_id: "f926a2fa-124e-4558-ba11-49127426010c"
            state: 'absent'
          register: result

    - name: Debug the result
      debug: var=result

'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible_collections.ansible.netcommon.plugins.module_utils.network.restconf import (
        restconf,
)

from ansible.module_utils.basic import AnsibleModule

class SFSFabricDelete(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'node_id': {
                'type': 'str',
                'required': False
            },
            'fabric_design': {
                'type': 'str',
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'design_node': {
                'type': 'str',
                'required': False
            },
            'fabric_design_mappings': {
                'type': 'list',
                'required': False
            },
            'nodes': {
                'type': 'list',
                'required': False
            },
            'fabric_id': {
                'type': 'str',
                'required': False
            },
            'description': {
                'type': 'str',
                'required': False
            },
            'physical_node': {
                'type': 'str',
                'required': False
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'NodeId' : 'node_id',
                'FabricDesignMappings' : 'fabric_design_mappings',
                'Nodes' : 'nodes',
                'Description' : 'description',
                'FabricDesign' : 'fabric_design',
                'Name' : 'name',
                #'DesignNode' : 'design_node',
                #'PhysicalNode' : 'physical_node'
                }

        self.path = "Fabrics('%s')"    % (self.module.params['fabric_id'])
        self.resource_id = self.module.params['node_id']

if __name__ == "__main__":
    SFSFabricDelete().execute_module()
