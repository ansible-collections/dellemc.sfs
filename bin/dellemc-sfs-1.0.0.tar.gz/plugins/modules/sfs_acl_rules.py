#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_acl_rules
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure acl rules on Dell SmartFabric Solutions.
description:
  - module provides configuration management of acl rules. 

options:
            'name': {
                'type': 'str',
                'required': False
            },
            'seq_no': {
                'type': 'int',
                'required': False
            },
            'destination_prefix': {
                'type': 'str',
                'required': False
            },
            'destination_mask': {
                'type': 'str',
                'required': False
            },
            'source_prefix': {
                'type': 'str',
                'required': False
            },
            'source_mask': {
                'type': 'str',
                'required': False
            },
            'destination_any': {
                'type': 'bool',
                'required': False
            },
            'source_any': {
                'type': 'bool',
                'required': False
            },
            'ip_protocol': {
                'type': 'int',
                'required': False
            },
            'source_port_range_comparator_port': {
                'type': 'int',
                'required': False
            },
            'destination_port_range_comparator_port': {
                'type': 'int',
                'required': False
            },
            'source_port_range_comparator': {
                'type': 'str',
                'required': False
            },
            'dest_port_range_comparator': {
                'type': 'str',
                'required': False
            },
            'remark': {
                'type': 'str',
                'required': False
            },
            'packet_handling': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: ACLRules configurations
          dellemc.sfs.sfs_acl_rules:
            name: "uplink-acl"
            seq_no: 9
            destination_prefix: "10.10.0.33"
            destination_mask: "255.255.255.255"
            source_prefix: "10.1.1.1"
            source_mask: "255.255.255.255"
            destination_any: false
            source_any: true
            ip_protocol: 4
            source_port_range_comparator_port: 200
            destination_port_range_comparator_port: 8000
            source_port_range_comparator: "ge"
            dest_port_range_comparator: "eq"
            packet_handling: "deny"
            remark: "ipacl9remark" ## Remark must be configured without any other additional attributes other than SeqNo. ##
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result

'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule


class SFSAclRules(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'seq_no': {
                'type': 'int',
                'required': False
            },
            'destination_prefix': {
                'type': 'str',
                'required': False
            },
            'destination_mask': {
                'type': 'str',
                'required': False
            },
            'source_prefix': {
                'type': 'str',
                'required': False
            },
            'source_mask': {
                'type': 'str',
                'required': False
            },
            'destination_any': {
                'type': 'bool',
                'required': False
            },
            'source_any': {
                'type': 'bool',
                'required': False
            },
            'ip_protocol': {
                'type': 'int',
                'required': False
            },
            'source_port_range_comparator_port': {
                'type': 'int',
                'required': False
            },
            'destination_port_range_comparator_port': {
                'type': 'int',
                'required': False
            },
            'source_port_range_comparator': {
                'type': 'str',
                'required': False
            },
            'dest_port_range_comparator': {
                'type': 'str',
                'required': False
            },
            'remark': {
                'type': 'str',
                'required': False
            },
            'packet_handling': {
                'type': 'str',
                'required': False
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'SeqNo' : 'seq_no',
                'DestinationPrefix' : 'destination_prefix',
                'DestinationMask' : 'destination_mask',
                'SourcePrefix' : 'source_prefix',
                'SourceMask' : 'source_mask',
                'DestinationAny' : 'destination_any',
                'SourceAny' : 'source_any',
                'IpProtocol' : 'ip_protocol',
                'SourcePortRangeComparatorPort' : 'source_port_range_comparator_port',
                'DestinationPortRangeComparatorPort' : 'destination_port_range_comparator_port',
                'SourcePortRangeComparator' : 'source_port_range_comparator',
                'DestPortRangeComparator' : 'dest_port_range_comparator',
                'Remark' : 'remark',
                'PacketHandling' : 'packet_handling'
                }

        self.path = "IpAcls('%s')/IpAclRules"    % (self.module.params['name'])
        self.resource_id = self.module.params['seq_no']

if __name__ == "__main__":
    SFSAclRules().execute_module()

