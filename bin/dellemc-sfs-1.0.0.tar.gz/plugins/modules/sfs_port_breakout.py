#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_port_breakout
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure port breakout on Dell SmartFabric Solutions.
description:

  - module provides configuration management of Interface BreakOut Capabilities. 

options:
            'interface_name': {
                'type': 'str',
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'target_port': {
                'type': 'str',
                'required': False
            },
            'fanout_profile': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections: 
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Port breakout configuration
          dellemc.sfs.sfs_port_breakout:
            target_port: "VB90DD3:phy-port1/1/24"
            fanout_profile: "HardwareDefault"
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule


class SFSPortBreakout(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'interface_name': {
                'type': 'str',
                'required': False
            },
            'name': {
                'type': 'str',
                'required': False
            },
            'target_port': {
                'type': 'str',
                'required': False
            },
            'fanout_profile': {
                'type': 'str',
                'required': False
            }
        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'InterfaceName' : 'interface_name',
                'Name' : 'name',
                'FanoutProfile' : 'fanout_profile'
                }

        self.path = "Interfaces('%s')"    % (self.module.params['target_port'])
        self.resource_id = self.module.params['name']

if __name__ == "__main__":
    SFSPortBreakout().execute_module()

