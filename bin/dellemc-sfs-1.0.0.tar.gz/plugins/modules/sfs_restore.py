#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: configure_sfs_setup
author: "Kalaivani Baskaran <kalaivani_baskaran_b@Dellteam.com>
short_description: Backup and restore functionality on Dell SmartFabric services.
description:
  - module restores configuration provided in given file

options:
            'file_name': {
                'type': 'str',
                'required': True
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    -  dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
         - name: SFS Restore
           dellemc.sfs.sfs_restore:
               file_name: '/home/administrator/backup.json'
           register: result
    - name: Debug the result
      debug: var=result
'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible.module_utils.basic import AnsibleModule
import json

class SFSRestore(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'file_name': {
                'type': 'str',
                'required': True
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module, False)
        bkp_file = open(module.params['file_name'], "r")
        file_contents = bkp_file.read()
        module.params.update(json.loads(file_contents))
        self.path = "Restore"
        # Get running config is set to false as it is not necessary for Restore module
        self.is_get_running = False
        self.keep_input_payload = True

if __name__ == "__main__":
    SFSRestore().execute_module()
