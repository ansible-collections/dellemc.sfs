#!/usr/bin/env python
# -*- coding: utf-8 -*-


from __future__ import (absolute_import, division, print_function)

DOCUMENTATION = '''
module: sfs_nodes_factory_default
author: "Ranjith Sunkesula" <Ranjith_Senkesula@Dellteam.com>
short_description: Configure Nodes Handler Factory Default on Dell SmartFabric Solutions.
description:

  - module provides configuration management of Nodes Handler Factory Default.

options:

            'node_id': {
                'type': 'str',
                'required': False
            }
'''
EXAMPLES = '''
Copy below YAML into a playbook (e.g. play.yml) and run as follows:

#$ ansible-playbook -i inventory play.yaml
- hosts: all
  gather_facts: false
  collections:
    - dellemc.sfs
  tasks:
    - name: Provision Configs
      block:
        - name: Factory default
          dellemc.sfs.sfs_nodes_factory_default:
            node_id: "VB9D06E"
            state: 'present'
          register: result

    - name: Debug the result
      debug: var=result

'''


from ansible_collections.dellemc.sfs.plugins.module_utils.sfs.sfs import SFSConfig, extract_id_value
from ansible_collections.ansible.netcommon.plugins.module_utils.network.restconf import (
        restconf,
)

from ansible.module_utils.basic import AnsibleModule


class SFSFactoryDefault(SFSConfig):
    def __init__(self):
        argument_spec = {
            'state': {
                'type': 'str',
                'default': "present",
                'required': False
            },
            'node_id': {
                'type': 'str',
                'required': False
            }

        }
        module = AnsibleModule(argument_spec=argument_spec)
        SFSConfig.__init__(self, module)
        self.payload_arg_map = {
                'NodeId' : 'node_id'
                }

        self.path = "Nodes('%s')/Nodes.FactoryDefault"    % (self.module.params['node_id'])
        self.resource_id = self.module.params['node_id']

if __name__ == "__main__":
    SFSFactoryDefault().execute_module()
